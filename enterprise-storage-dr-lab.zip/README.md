# Enterprise Storage & Disaster Recovery Lab (Simulated)

## 📌 Overview
This project demonstrates a **simulated enterprise IT architecture** for learning and portfolio purposes.  
It covers:
- Enterprise Storage (SAN, NAS, Object Storage)
- Virtualization Concepts (VMware ESXi / Hyper-V)
- Disaster Recovery & Backup
- Basic Automation (Bash + Ansible)

## 🏗️ Architecture
![Architecture Diagram](architecture.png)

**Flow:**  
Users → Virtualization Cluster → SAN/NAS → Backup to Object Storage → Disaster Recovery Site

## 🔑 Features
✔️ Simulated SAN/NAS/Object storage setup  
✔️ Virtualization cluster concepts with HA/Failover  
✔️ Backup & recovery automation scripts  
✔️ Disaster Recovery plan (RTO/RPO based)  
✔️ Monitoring & capacity planning documentation  

## 🛠️ Components
- **Storage:** FreeNAS/TrueNAS (SAN/NAS), MinIO (Object Storage)  
- **Virtualization:** VMware ESXi + Hyper-V concepts  
- **Automation:** Ansible + Bash  
- **Monitoring:** Zabbix + Grafana (documented, not deployed)

## 📂 Repository Contents
- `architecture.png` → Diagram of system design  
- `backup.sh` → Simple backup automation script  
- `ansible-playbook.yml` → Example of storage provisioning automation  
- `dr-plan.md` → Disaster Recovery plan and testing notes  

## 📊 Resume-Ready Highlights
- Designed a **simulated enterprise storage & DR lab** aligned with government IT standards.  
- Created **automation scripts** for backup and storage provisioning.  
- Documented a **disaster recovery plan** with RTO/RPO metrics.  

---
🚀 This project is for demonstration and learning purposes only.
