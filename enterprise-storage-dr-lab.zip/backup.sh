#!/bin/bash
# Simple Backup Script (Simulation)

SRC="/home/user/data"
DEST="/backups/data-$(date +%F).tar.gz"

echo "Starting backup..."
mkdir -p /backups
tar -czf $DEST $SRC 2>/dev/null
echo "Backup completed: $DEST"
