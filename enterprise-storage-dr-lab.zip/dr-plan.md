# Disaster Recovery Plan (Simulation)

## 🔹 Objectives
- **RTO (Recovery Time Objective):** 2 hours  
- **RPO (Recovery Point Objective):** 15 minutes  

## 🔹 Strategy
1. Daily backups to local storage.  
2. Weekly replication to remote site (simulated).  
3. Regular backup integrity testing.  
4. Document failover/failback processes.  

## 🔹 Test Report (Simulated)
- Backup verified ✅  
- Replication verified ✅  
- Failover tested: Recovery completed within 90 minutes.  
- Failback successful.  

## 🔹 Future Enhancements
- Add cloud-based DR (AWS/Azure).  
- Automate failover testing with Ansible.  
